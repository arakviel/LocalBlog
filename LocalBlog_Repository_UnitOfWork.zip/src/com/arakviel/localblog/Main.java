package com.arakviel.localblog;

import static java.lang.System.out;

import com.arakviel.localblog.persistence.entity.impl.User;
import com.arakviel.localblog.persistence.repository.RepositoryFactory;
import com.arakviel.localblog.persistence.repository.contracts.UserRepository;
import com.github.javafaker.Faker;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class Main {

    public static void main(String[] args) {
        Set<User> users = generateUsers(10);

        RepositoryFactory jsonRepositoryFactory = RepositoryFactory
                .getRepositoryFactory(RepositoryFactory.JSON);
        UserRepository userRepository = jsonRepositoryFactory.getUserRepository();

        // Виведемо створених користувачів

        int i = 0;
        for (User user : users) {
            userRepository.add(user);
            if (i == 3) {
                userRepository.remove(user);
            }
            if (i == 5) {
                userRepository.remove(user);
            }
            if (i == 7) {
                userRepository.remove(user);
            }
            i++;
        }

        userRepository.findAll().forEach(out::println);

        // Цей рядок, має бути обовязково в кінці метода main!!!!
        jsonRepositoryFactory.commit();
    }

    public static Set<User> generateUsers(int count) {
        Set<User> users = new HashSet<>();
        Faker faker = new Faker();

        for (int i = 0; i < count; i++) {
            UUID userId = UUID.randomUUID();
            String password = faker.internet().password();
            String email = faker.internet().emailAddress();
            LocalDate birthday = faker.date()
                    .birthday()
                    .toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            String username = faker.name().username();
            String avatar = faker.internet().avatar();

            User user = new User(userId, password, email, birthday, username, avatar);
            users.add(user);
        }

        return users;
    }
}
