package com.arakviel.localblog.domain.exception;

public class SignUpException extends RuntimeException {

    public SignUpException(String message) {
        super(message);
    }
}
