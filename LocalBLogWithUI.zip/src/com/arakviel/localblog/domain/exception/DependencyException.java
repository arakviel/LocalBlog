package com.arakviel.localblog.domain.exception;

public class DependencyException extends RuntimeException {

    public DependencyException(String message) {
        super(message);
    }
}
